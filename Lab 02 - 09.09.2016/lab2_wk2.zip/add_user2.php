<?php
    
    require_once 'bilingual.inc';
    // Get the value of the parameter sent by clicking Eng/Thai link
    // If the user accesses the web without selecting the language, set to English by default
    //$lang = $_GET[....] 

    // If English was selected, 
    //  $sys = new ITS331Eng();    
    // If Thai was selected, 
    //  $sys = new ITS331Thai();
    
    // replace the text in this page by calling an appropriate method on $sys 
?>
<!DOCTYPE html>
<html>
<head>
<title>ITS331 System </title>
<link rel="stylesheet" href="default2.css">
</head>

<body>

<div id="wrapper"> 
	<div id="subwrapper">
		<div id="div_header">
			ITS331 System 
		</div>
		<div id="div_subhead">
			<ul id="menu">
				<li><a href="user.php">User Profile</a></li>
				<li><a href="add_user.html">Add User</a></li>
				<li><a href="group.php">User Group</a></li>
				<li><a href="add_group.html">Add User Group</a></li>
            
				<li style="float:right">
					<a href="add_user2.php">Eng</a>/
					<a href="add_user2.php">Thai</a>
				</li>
			</ul>		
		</div>
		<div id="div_main">
			<div id="div_content" class="form">
				<!--%%%%% Main block %%%%-->
				<!--Form -->
				
				<form action="user.php" method="post">
					<h2>User Profile</h2>
					<label>Title</label>
					<select name="title">
						<option value="Mr.">Mr.</option>
						<option value="Mrs.">Mrs.</option>
						<option value="Ms.">Ms.</option>
					</select>
					
					<label>First name</label>
					<input type="text" name="firstname">
						
					<label>Last name</label>
					<input type="text" name="lastname">

					<label>Gender</label>
					<input type="radio" name="gender" value="male" checked>Male
					<input type="radio" name="gender" value="female">
					Female
					<div></div>
					
					<label>Email</label>
					<input type="text" name="email">
					
					
					<div class="center">
						<input type="submit" value="Submit" >			
					</div>
				</form>
				
			</div> <!-- end div_content -->
			<div id="div_right">
					
			</div>
		</div> <!-- end div_main -->
		
		<div id="div_footer">  
			Adapted theme from wordpress.com
		</div>

	</div>
</div>
</body>
</html>


